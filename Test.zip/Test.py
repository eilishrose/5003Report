import matplotlib
import matplotlib.pyplot
import csv
import matplotlib.animation

snowslope =[]

# Import raster data set and append data to list
f = open('in.txt', newline='' )
reader = csv.reader(f,  delimiter=',', quoting=csv.QUOTE_NONNUMERIC)
for row in reader: 
    rowlist = []
    snowslope.append(rowlist)
    for value in row:
        rowlist.append(value)
        #print(value)
f.close()

matplotlib.pyplot.xlim(0, 99)
matplotlib.pyplot.ylim(0, 99)
matplotlib.pyplot.imshow(snowslope)
